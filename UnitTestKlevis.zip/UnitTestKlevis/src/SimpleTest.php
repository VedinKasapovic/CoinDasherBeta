<?php
// Simple test class
class SimpleTest
{
    // Method to check if two values are equal
    public function assertEqual($expected, $actual, $testName)
    {
        if ($expected === $actual) {
            echo "$testName: PASS\n";
        } else {
            echo "$testName: FAIL (Expected: $expected, Got: $actual)\n";
        }
    }

    // Method to check if a value is true
    public function assertTrue($condition, $testName)
    {
        if ($condition) {
            echo "$testName: PASS\n";
        } else {
            echo "$testName: FAIL\n";
        }
    }
}
?>
