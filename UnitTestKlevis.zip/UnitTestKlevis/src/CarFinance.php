<?php
class CarFinance
{
    private $car_price;
    private $down_payment;
    private $loan_term;
    private $interest_rate;

    public function __construct($car_price, $down_payment, $loan_term, $interest_rate)
    {
        $this->car_price = $car_price;
        $this->down_payment = $down_payment;
        $this->loan_term = $loan_term;
        $this->interest_rate = $interest_rate;
    }

    public function calculateMonthlyPayment()
    {
        $loan_amount = $this->car_price - $this->down_payment;
        $monthly_rate = $this->interest_rate / 12 / 100;
        $num_payments = $this->loan_term * 12;
        $monthly_payment = ($loan_amount * $monthly_rate) / (1 - pow(1 + $monthly_rate, -$num_payments));

        return round($monthly_payment, 2); // rounding to 2 decimal places
    }
}
?>
