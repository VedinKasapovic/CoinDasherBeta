<footer class="footer">
    <p>Web dev serverside</p> <!-- You can replace this with additional footer content if needed -->
</footer>

</body>
</html>
