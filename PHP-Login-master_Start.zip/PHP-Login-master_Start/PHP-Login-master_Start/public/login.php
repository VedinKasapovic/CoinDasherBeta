<?php 
require_once('config.php');  // Import username and password
session_start();  // Start the session

if (isset($_POST['Submit'])) {
    // Check if the entered username and password match
    if ($_POST['Username'] == $Username && $_POST['Password'] == $Password) {
        $_SESSION['Username'] = $Username;  // Store username in session
        $_SESSION['Active'] = true;  // Mark the user as logged in
        header("Location: index.php");  // Redirect to the index page
        exit;
    } else {
        echo 'Incorrect Username or Password';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/signin.css">  <!-- Login page specific styles -->
    <link rel="stylesheet" href="../css/stylesheet.css">
    <title>Sign in</title>
</head>
<body>
    <div class="container">
        <form action="" method="post" class="form-signin">
            <h2>Please sign in</h2>
            <label for="inputUsername">Username</label>
            <input type="text" name="Username" id="inputUsername" class="form-control" placeholder="Username" required>
            
            <label for="inputPassword">Password</label>
            <input type="password" name="Password" id="inputPassword" class="form-control" placeholder="Password" required>

            <button name="Submit" type="submit" class="button">Sign in</button>
        </form>
    </div>
</body>
</html>
