<?php
session_start();  // Start the session
if (!isset($_SESSION['Active']) || $_SESSION['Active'] !== true) {
    header("Location: login.php");  // Redirect to login page if not logged in
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/stylesheet.css">
    <title>Contact</title>
</head>
<body>
    <?php include('template/header.php'); ?>  <!-- Correct path to header.php -->

    <div class="container">
        <h3>Contact page - <?php echo $_SESSION['Username']; ?></h3>
        <p>Some content goes here...</p>

        <form action="logout.php" method="post" class="form-signin">
            <button name="Submit" value="Logout" class="button" type="submit">Log out</button>
        </form>
    </div>

    <?php include('template/footer.php'); ?>  <!-- Correct path to footer.php -->
</body>
</html>
