<?php
session_start();  // Start the session
if (!isset($_SESSION['Active']) || $_SESSION['Active'] !== true) {
    header("Location: login.php");  // Redirect to login page if not logged in
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/stylesheet.css">
    <title>Home Page</title>
</head>
<body>
<?php include('C:/laragon/www/PHP-Login-master_Start/PHP-Login-master_Start/template/header.php'); ?>  <!-- Correct path to header.php -->
    <div class="container">
        <h1>Status: You are logged in, <span style="font-weight: bold; color: #F2A900;"><?php echo $_SESSION['Username']; ?></span></h1>
        <p class="lead">This is where we will put the logout button</p>

        <form action="logout.php" method="post" class="form-signin">
            <button name="Submit" value="Logout" class="button" type="submit">Log out</button>
        </form>

        <div class="row marketing">
            <div class="col-lg-12">
                <h4>Home page</h4>
                <p>Some content goes here. Some content goes here. Some content goes here. Some content goes here. Some content goes here. Some content goes here. Some content goes here.</p>
            </div>
        </div>
    </div>

    <?php include('C:/laragon/www/PHP-Login-master_Start/PHP-Login-master_Start/template/footer.php'); ?>  <!-- Correct path to footer.php -->
</body>
</html>
