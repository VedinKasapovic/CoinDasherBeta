<?php
$Username = 'Steve';  // Hardcoded username
$Password = 'pass';  // Hardcoded password
?>
